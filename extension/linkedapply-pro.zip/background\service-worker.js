const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/reminder-service-DLKb9z8W.js","chunks/constants-fenB-1Hb.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from '../chunks/preload-helper-BelkbqnE.js';
import { c as createLogger, g as getStorage, S as STORAGE_KEYS, s as setStorage, d as DEFAULT_SESSION } from '../chunks/constants-fenB-1Hb.js';
import { createAIProviderFromStorage } from '../chunks/ai-provider-ClgdvtWL.js';
import { g as getUsageState, r as recordAICall } from '../chunks/usage-tracker-Cq_ZrhMj.js';

const JOB_MATCH_PROMPT = `
You are a career advisor. Evaluate candidate-job fit. You MUST extract and list all qualifications from the job description.

CANDIDATE:
{userProfile}

JOB:
{jobDescription}

RULES:
- Extract EVERY qualification from the JD. requiredQualifications and preferredQualifications arrays are MANDATORY and must NOT be empty.
- Keep descriptions short (under 10 words each).
- Omit the "note" field unless the match is partial.

Return ONLY valid JSON:
{
  "score": <0-100>,
  "headline": "<short: e.g. Top applicant OR Low match>",
  "recommendation": "<1 sentence>",
  "shouldApply": <true/false>,
  "strengths": ["<skill1>", "<skill2>"],
  "gaps": ["<gap1>"],
  "requiredQualifications": [
    {"description": "<short qual>", "matched": true},
    {"description": "<short qual>", "matched": false, "note": "<why>"}
  ],
  "preferredQualifications": [
    {"description": "<short qual>", "matched": true}
  ]
}
`;
const JD_KEYWORDS_PROMPT = `
Extract the top keywords from this job description. Categorize them.

JOB DESCRIPTION:
{jobDescription}

Return ONLY valid JSON:
{
  "hardSkills": ["Java", "Spring Boot", "PostgreSQL"],
  "softSkills": ["leadership", "communication"],
  "tools": ["Docker", "AWS", "Jenkins", "Git"],
  "domain": ["fintech", "microservices", "REST API"],
  "seniority": ["senior", "3+ years", "lead"],
  "jobTitle": "Software Engineer"
}
`;
const PARSE_RESUME_PROMPT = `
Parse this resume into an ORDERED array of sections. Return EVERY section found in the resume. Copy all text VERBATIM — do NOT modify, rephrase, or improve anything.

RESUME TEXT:
{resumeText}

Return ONLY valid JSON — an array of section objects. The FIRST section MUST be "header" with contact info. Each section has "name", "type", and type-specific content:

[
  {
    "name": "Header",
    "type": "header",
    "fullName": "John Doe",
    "email": "john@email.com",
    "phone": "123-456-7890",
    "location": "City, State",
    "linkedin": "linkedin.com/in/johndoe",
    "github": "github.com/johndoe",
    "portfolio": "johndoe.com"
  },
  {
    "name": "Professional Summary",
    "type": "summary",
    "text": "exact summary paragraph from resume"
  },
  {
    "name": "Technical Skills",
    "type": "skills",
    "categories": {"Languages": "Java, Python", "Frameworks": "Spring Boot, React"},
    "items": ["Java", "Python", "Spring Boot"]
  },
  {
    "name": "Professional Experience",
    "type": "experience",
    "entries": [
      {"company": "Company", "location": "City, State", "title": "Job Title", "duration": "Mon YYYY -- Present", "bullets": ["exact bullet 1", "exact bullet 2"]}
    ]
  },
  {
    "name": "Personal Projects",
    "type": "projects",
    "entries": [
      {"name": "Project Name", "techStack": "tech1, tech2", "duration": "Mon YYYY -- Mon YYYY", "bullets": ["exact bullet"]}
    ]
  },
  {
    "name": "Education",
    "type": "education",
    "entries": [
      {"institution": "University", "location": "City, State", "degree": "Degree Name", "year": "YYYY"}
    ]
  },
  {
    "name": "Certifications",
    "type": "list",
    "items": ["Cert name 1"]
  }
]

SECTION TYPES:
- "header": contact info (MUST be first — extract name, email, phone, location, and any links like LinkedIn/GitHub/Portfolio from the resume header)
- "summary": paragraph text (use for Summary, Objective, Profile)
- "skills": categorized skills (use for Technical Skills, Core Competencies)
- "experience": work entries with bullets (use for Experience, Work History)
- "projects": project entries with bullets (use for Projects)
- "education": education entries (use for Education)
- "list": simple bullet items (use for Certifications, Achievements, Awards, Publications, Volunteer, Languages, Interests, Honors, or any other section)

CRITICAL RULES:
1. Copy ALL text VERBATIM — do not rephrase, summarize, or improve
2. The FIRST section MUST be "header" with the person's name and contact details
3. Return remaining sections in the SAME ORDER as the resume
4. Include EVERY section found — do not skip any
5. Include ALL entries and ALL bullets within each section
6. Use "list" type for any section not matching the other types
7. If a contact field (email, phone, etc.) is not in the resume, omit it
`;
const COVER_LETTER_PROMPT = `
Write a personalized cover letter for this job application.

CANDIDATE:
{userProfile}

JOB: {jobTitle} at {company}
{jobDescription}

RULES:
- Open with a strong hook (NOT "I am writing to apply...")
- Connect candidate's experience to job requirements
- Professional but conversational tone
- Under 300 words total

Return ONLY valid JSON:
{
  "subject": "Application for <job title>",
  "greeting": "Dear Hiring Manager,",
  "body": ["<paragraph 1>", "<paragraph 2>", "<paragraph 3>"],
  "closing": "Sincerely,",
  "signature": "<candidate full name>"
}
`;
const STAND_OUT_TIPS_PROMPT = `
Help this candidate stand out for this job application. Like LinkedIn Premium's "Help Stand Out" feature.

CANDIDATE:
{userProfile}

JOB: {jobTitle} at {company}
{jobDescription}

Provide actionable tips. Keep each tip under 15 words.

Return ONLY valid JSON:
{
  "highlightSkills": ["<skill to emphasize in application>", "<skill>"],
  "highlightAchievements": ["<achievement to mention>", "<achievement>"],
  "profileImprovements": ["<specific LinkedIn profile improvement>", "<improvement>"]
}
`;
function fillPrompt(template, values) {
  return template.replace(/\{(\w+)\}/g, (match, key) => {
    return values[key] ?? "N/A";
  });
}

const log$4 = createLogger("AI:Matcher");
async function aiMatchJob(client, profile, jobDescription, resumeText, skillsMap) {
  try {
    log$4.info("Calculating job match score...");
    const userProfileStr = formatProfileForAI(profile, resumeText, skillsMap);
    const prompt = fillPrompt(JOB_MATCH_PROMPT, {
      userProfile: userProfileStr,
      jobDescription: jobDescription.substring(0, 3e3)
    });
    const result = await client.completeJSON(prompt, {
      temperature: 0.1,
      maxTokens: 4e3
    });
    result.score = Math.max(0, Math.min(100, result.score));
    result.requiredQualifications = result.requiredQualifications || [];
    result.preferredQualifications = result.preferredQualifications || [];
    result.strengths = result.strengths || [];
    result.gaps = result.gaps || [];
    result.headline = result.headline || (result.score >= 80 ? "You'd be a top applicant" : result.score >= 60 ? "Good match for this role" : "Job match is low");
    const reqMatched = result.requiredQualifications.filter((q) => q.matched).length;
    const reqTotal = result.requiredQualifications.length;
    log$4.info(`Job match: ${result.score}/100 — ${reqMatched}/${reqTotal} required quals matched (${result.headline})`);
    return result;
  } catch (error) {
    const msg = error?.message || "";
    if (msg.includes("quota") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("503")) {
      throw error;
    }
    log$4.error("Job matching failed", error);
    return null;
  }
}
function formatProfileForAI(profile, resumeText, skillsMap) {
  const parts = [
    `Name: ${profile.firstName} ${profile.lastName}`,
    `Location: ${profile.currentCity}, ${profile.state}, ${profile.country}`
  ];
  if (skillsMap && Object.keys(skillsMap).length > 0) {
    const skillsList = Object.entries(skillsMap).map(([skill, years]) => `${skill} (${years} years)`).join(", ");
    parts.push(`Skills: ${skillsList}`);
  }
  if (resumeText) {
    parts.push(`
RESUME:
${resumeText.substring(0, 2500)}`);
  }
  return parts.filter(Boolean).join("\n");
}

const log$3 = createLogger("AI:Resume");
async function aiTailorResume(client, profile, jobDescription, _skills, resumeText, skillsMap) {
  try {
    let sections = await getStorage(STORAGE_KEYS.RESUME_STRUCTURED);
    if (!sections && resumeText) {
      log$3.info("First-time resume parsing with AI (will be cached)...");
      const parsePrompt = fillPrompt(PARSE_RESUME_PROMPT, {
        resumeText: resumeText.substring(0, 8e3)
      });
      const parsed = await client.completeJSON(parsePrompt, {
        temperature: 0.1,
        maxTokens: 8e3
      });
      sections = (Array.isArray(parsed) ? parsed : []).map((s) => ({
        ...s,
        type: s.type || "list",
        entries: s.entries || void 0,
        items: s.items || void 0,
        text: s.text || void 0,
        categories: s.categories || void 0
      }));
      await setStorage(STORAGE_KEYS.RESUME_STRUCTURED, sections);
      log$3.info(`Resume parsed and cached: ${sections.length} sections [${sections.map((s) => s.name).join(", ")}]`);
    }
    if (!sections || sections.length === 0) {
      log$3.warn("No resume text available for parsing");
      return null;
    }
    log$3.info("Extracting JD keywords...");
    const jdPrompt = fillPrompt(JD_KEYWORDS_PROMPT, {
      jobDescription: jobDescription.substring(0, 2e3)
    });
    const jdKeywords = await client.completeJSON(jdPrompt, {
      temperature: 0.1,
      maxTokens: 2e3
    });
    const allJdKeywords = [
      ...jdKeywords.hardSkills || [],
      ...jdKeywords.softSkills || [],
      ...jdKeywords.tools || [],
      ...jdKeywords.domain || []
    ].map((k) => k.toLowerCase());
    log$3.info(`JD keywords: ${allJdKeywords.length} total, title: "${jdKeywords.jobTitle}"`);
    const tailoredSections = sections.map((section) => tailorSection(section, allJdKeywords));
    const allSkills = collectSkills(sections);
    const matchedSkills = allSkills.filter(
      (s) => allJdKeywords.some((jk) => fuzzyMatch(s, jk))
    );
    const summaryIdx = tailoredSections.findIndex((s) => s.type === "summary");
    if (summaryIdx >= 0) {
      const title = jdKeywords.jobTitle || "Software Engineer";
      const topSkills = matchedSkills.slice(0, 5).join(", ");
      const years = skillsMap ? Math.max(...Object.values(skillsMap), 1) : sections.some((s) => s.type === "experience") ? "3+" : "1+";
      tailoredSections[summaryIdx] = {
        ...tailoredSections[summaryIdx],
        text: topSkills ? `${title} with ${years} years of experience specializing in ${topSkills}. Skilled in ${jdKeywords.domain.slice(0, 3).join(", ") || "building scalable applications"} with a track record of delivering production-grade solutions.` : `${title} with ${years} years of experience in software development. Experienced in ${allSkills.slice(0, 5).join(", ") || "full-stack development"}.`
      };
    }
    const totalJd = allJdKeywords.length || 1;
    const atsScore = Math.min(98, Math.round(matchedSkills.length / totalJd * 80 + 20));
    log$3.info(`Resume tailored — ATS: ${atsScore}/100, ${matchedSkills.length} keywords matched, ${tailoredSections.length} sections`);
    return {
      sections: tailoredSections,
      atsScore,
      keywordsAdded: matchedSkills,
      allSkills
    };
  } catch (error) {
    const msg = error?.message || "";
    if (msg.includes("quota") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("503")) {
      throw error;
    }
    log$3.error("Hybrid tailoring failed", error);
    return null;
  }
}
function tailorSection(section, jdKeywords) {
  switch (section.type) {
    case "skills": {
      const reorderedItems = section.items ? reorderItems(section.items, jdKeywords) : void 0;
      return { ...section, items: reorderedItems };
    }
    case "experience": {
      const entries = (section.entries || []).map((e) => ({
        ...e,
        bullets: reorderBullets(e.bullets || [], jdKeywords)
      }));
      return { ...section, entries };
    }
    case "projects": {
      const entries = (section.entries || []).map((p) => ({
        ...p,
        bullets: reorderBullets(p.bullets || [], jdKeywords)
      }));
      return { ...section, entries };
    }
    default:
      return section;
  }
}
function collectSkills(sections) {
  const skills = [];
  sections.forEach((s) => {
    if (s.type === "skills") {
      if (s.items) skills.push(...s.items);
      if (s.categories) {
        Object.values(s.categories).forEach((v) => {
          v.split(",").forEach((sk) => {
            const t = sk.trim();
            if (t && !skills.includes(t)) skills.push(t);
          });
        });
      }
    }
  });
  return skills;
}
function fuzzyMatch(a, b) {
  const normalize = (s) => s.toLowerCase().replace(/[\s\-_\.]/g, "");
  return normalize(a) === normalize(b) || normalize(a).includes(normalize(b)) || normalize(b).includes(normalize(a));
}
function reorderItems(items, jdKeywords) {
  const matched = items.filter((s) => jdKeywords.some((jk) => fuzzyMatch(s, jk)));
  const unmatched = items.filter((s) => !jdKeywords.some((jk) => fuzzyMatch(s, jk)));
  return [...matched, ...unmatched];
}
function reorderBullets(bullets, jdKeywords) {
  const scored = bullets.map((bullet) => {
    const lower = bullet.toLowerCase();
    const matchCount = jdKeywords.filter((kw) => lower.includes(kw)).length;
    return { bullet, matchCount };
  });
  scored.sort((a, b) => b.matchCount - a.matchCount);
  return scored.map((s) => s.bullet);
}

const log$2 = createLogger("AI:CoverLetter");
async function aiGenerateCoverLetter(client, profile, jobTitle, company, jobDescription) {
  try {
    log$2.info(`Generating cover letter for "${jobTitle}" at ${company}...`);
    const userProfileStr = [
      `Name: ${profile.firstName} ${profile.lastName}`,
      `Email: ${profile.email}`,
      `Phone: ${profile.phoneNumber}`,
      `Location: ${profile.currentCity}, ${profile.state}`
    ].join("\n");
    const prompt = fillPrompt(COVER_LETTER_PROMPT, {
      userProfile: userProfileStr,
      jobTitle,
      company,
      jobDescription: jobDescription.substring(0, 3e3)
    });
    const result = await client.completeJSON(prompt, {
      temperature: 0.5,
      maxTokens: 2e3
    });
    result.body = result.body || [];
    result.subject = result.subject || `Application for ${jobTitle}`;
    result.greeting = result.greeting || "Dear Hiring Manager,";
    result.closing = result.closing || "Sincerely,";
    result.signature = result.signature || `${profile.firstName} ${profile.lastName}`;
    const plainText = [
      result.greeting,
      "",
      ...result.body.map((p) => p + "\n"),
      result.closing,
      result.signature
    ].join("\n");
    const coverLetterData = {
      subject: result.subject,
      plainText,
      greeting: result.greeting,
      bodyParagraphs: result.body,
      closing: result.closing,
      signature: result.signature,
      generatedAt: Date.now(),
      jobTitle,
      company
    };
    log$2.info(`Cover letter generated (${plainText.length} chars, ${result.body.length} paragraphs)`);
    return coverLetterData;
  } catch (error) {
    const msg = error?.message || "";
    if (msg.includes("quota") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("503")) {
      throw error;
    }
    log$2.error("Cover letter generation failed", error);
    return null;
  }
}

const log$1 = createLogger("AI:StandOut");
async function aiGenerateStandOutTips(client, profile, jobTitle, company, jobDescription) {
  try {
    log$1.info(`Generating stand-out tips for "${jobTitle}" at ${company}...`);
    const userProfileStr = [
      `Name: ${profile.firstName} ${profile.lastName}`,
      `Email: ${profile.email}`,
      `Location: ${profile.currentCity}, ${profile.state}`,
      `Education: ${profile.highestEducation || "N/A"}`
    ].join("\n");
    const prompt = fillPrompt(STAND_OUT_TIPS_PROMPT, {
      userProfile: userProfileStr,
      jobTitle,
      company,
      jobDescription: jobDescription.substring(0, 2e3)
    });
    const result = await client.completeJSON(prompt, {
      temperature: 0.4,
      maxTokens: 1500
    });
    result.highlightSkills = result.highlightSkills || [];
    result.highlightAchievements = result.highlightAchievements || [];
    result.profileImprovements = result.profileImprovements || [];
    log$1.info(`Stand-out tips generated: ${result.highlightSkills.length} skills, ${result.highlightAchievements.length} achievements, ${result.profileImprovements.length} improvements`);
    return result;
  } catch (error) {
    const msg = error?.message || "";
    if (msg.includes("quota") || msg.includes("429") || msg.includes("RESOURCE_EXHAUSTED") || msg.includes("503")) {
      throw error;
    }
    log$1.error("Stand-out tips generation failed", error);
    return null;
  }
}

const log = createLogger("ServiceWorker");
chrome.runtime.onInstalled.addListener((details) => {
  log.info(`Extension ${details.reason}`, { version: chrome.runtime.getManifest().version });
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }).catch(log.error);
  if (details.reason === "install") {
    initializeDefaults().catch((err) => log.error("Failed to initialize defaults", err));
  }
});
async function initializeDefaults() {
  const existing = await getStorage(STORAGE_KEYS.BOT_STATUS);
  if (!existing) {
    await setStorage(STORAGE_KEYS.BOT_STATUS, "idle");
    await setStorage(STORAGE_KEYS.SESSION_SUMMARY, DEFAULT_SESSION);
    log.info("Default storage values initialized");
  }
}
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    log.info(`Message received: ${message.type}`, { from: sender.tab?.id || "popup/sidepanel" });
    switch (message.type) {
      case "START_BOT":
        handleStartBot(sender.tab?.id);
        sendResponse({ success: true });
        break;
      case "STOP_BOT":
        handleStopBot(sender.tab?.id);
        sendResponse({ success: true });
        break;
      case "PAUSE_BOT":
      case "RESUME_BOT":
        forwardToContentScript(message, sender.tab?.id);
        sendResponse({ success: true });
        break;
      case "STATUS_UPDATE":
        handleStatusUpdate(message.payload);
        break;
      case "JOB_APPLIED":
        handleJobApplied(message.payload);
        sendResponse({ success: true });
        break;
      case "JOB_FAILED":
        handleJobFailed(message.payload);
        sendResponse({ success: true });
        break;
      case "JOB_SKIPPED":
        handleJobSkipped(message.payload);
        sendResponse({ success: true });
        break;
      case "OPEN_SIDEPANEL":
        openSidePanel(sender);
        sendResponse({ success: true });
        break;
      case "RETRY_JOB":
        handleRetryJob(message.payload?.jobLink);
        sendResponse({ success: true });
        break;
      case "GET_STATUS":
        getStatus().then(sendResponse);
        return true;
      case "AI_MATCH_JOB":
        handleAIMatchJob(message.payload).then(sendResponse);
        return true;
      case "AI_TAILOR_RESUME":
        handleAITailorResume(message.payload).then(sendResponse);
        return true;
      case "AI_COVER_LETTER":
        handleAICoverLetter(message.payload).then(sendResponse);
        return true;
      case "AI_STANDOUT_TIPS":
        handleAIStandOutTips(message.payload).then(sendResponse);
        return true;
      case "GET_USAGE":
        getUsageState().then(sendResponse);
        return true;
      case "PRE_APPLY_REVIEW":
        chrome.runtime.sendMessage(message).catch(() => {
        });
        sendResponse({ success: true });
        break;
      default:
        sendResponse({ error: "Unknown message type" });
    }
    return true;
  }
);
async function handleStartBot(tabId) {
  log.info("Starting bot...");
  await setStorage(STORAGE_KEYS.BOT_STATUS, "searching");
  const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY) || { ...DEFAULT_SESSION };
  session.startTime = (/* @__PURE__ */ new Date()).toISOString();
  session.totalRuns += 1;
  await setStorage(STORAGE_KEYS.SESSION_SUMMARY, session);
  updateBadge(session.easyApplied, "running");
  await sendToLinkedInTab({
    type: "START_BOT",
    timestamp: Date.now()
  });
}
async function handleStopBot(tabId) {
  log.info("Stopping bot...");
  await setStorage(STORAGE_KEYS.BOT_STATUS, "stopped");
  const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY);
  if (session) {
    session.endTime = (/* @__PURE__ */ new Date()).toISOString();
    await setStorage(STORAGE_KEYS.SESSION_SUMMARY, session);
  }
  const tabs = await chrome.tabs.query({ url: "https://www.linkedin.com/*" });
  tabs.forEach((tab) => {
    if (tab.id) {
      chrome.tabs.sendMessage(tab.id, {
        type: "STOP_BOT",
        timestamp: Date.now()
      }).catch(() => {
      });
    }
  });
  broadcastUpdate();
  updateBadge(0, "stopped");
}
async function sendToLinkedInTab(message) {
  try {
    const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTab = activeTabs[0];
    if (activeTab?.id && activeTab.url && activeTab.url.includes("linkedin.com")) {
      try {
        await chrome.tabs.sendMessage(activeTab.id, message);
        log.info(`Message ${message.type} sent to active LinkedIn tab ${activeTab.id}`);
        return true;
      } catch (err) {
        log.warn("Active LinkedIn tab did not respond (content script may need reload). Reloading tab...", err);
        await chrome.tabs.reload(activeTab.id);
        waitForTabAndSend(activeTab.id, message);
        return true;
      }
    }
  } catch (err) {
    log.warn("Error checking active tab", err);
  }
  try {
    const linkedInTabs = await chrome.tabs.query({ url: "https://www.linkedin.com/*" });
    for (const tab of linkedInTabs) {
      if (tab.id) {
        try {
          await chrome.tabs.update(tab.id, { active: true });
          await chrome.tabs.sendMessage(tab.id, message);
          log.info(`Message ${message.type} sent to existing LinkedIn tab ${tab.id}`);
          return true;
        } catch (err) {
          log.warn(`LinkedIn tab ${tab.id} not responding, checking next...`, err);
        }
      }
    }
  } catch (err) {
    log.warn("Error querying LinkedIn tabs", err);
  }
  try {
    log.info("Opening new LinkedIn tab at https://www.linkedin.com/jobs/search/...");
    const newTab = await chrome.tabs.create({ url: "https://www.linkedin.com/jobs/search/", active: true });
    if (newTab.id) {
      waitForTabAndSend(newTab.id, message);
      return true;
    }
  } catch (err) {
    log.error("Failed to create new LinkedIn tab", err);
  }
  return false;
}
function waitForTabAndSend(tabId, message) {
  const listener = (id, changeInfo) => {
    if (id === tabId && changeInfo.status === "complete") {
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(() => {
        chrome.tabs.sendMessage(tabId, message).catch((err) => {
          log.warn(`Failed to send ${message.type} to loaded tab ${tabId}`, err);
        });
      }, 2500);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
  setTimeout(() => chrome.tabs.onUpdated.removeListener(listener), 3e4);
}
async function handleStatusUpdate(payload) {
  if (payload?.status) {
    await setStorage(STORAGE_KEYS.BOT_STATUS, payload.status);
    if (payload.status === "stopped") {
      const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY);
      const applied = session?.easyApplied || 0;
      showNotification(
        "stopped",
        "⏹️ Bot Stopped",
        applied > 0 ? `Session complete — ${applied} applications sent.` : "Automation has been stopped."
      );
    } else if (payload.status === "error") {
      showNotification(
        "error",
        "⚠️ Bot Error",
        "The bot encountered an error and stopped. Check the dashboard for details."
      );
    }
  }
  broadcastUpdate();
}
async function handleJobApplied(payload) {
  const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY) || { ...DEFAULT_SESSION };
  log.info(`Job applied! Total: ${session.easyApplied}`);
  updateBadge(session.easyApplied, "running");
  if (session.easyApplied % 5 === 0) {
    showNotification(
      "progress",
      `🚀 ${session.easyApplied} Applications Sent!`,
      `You've applied to ${session.easyApplied} jobs this session. Keep going!`
    );
  }
  if (session.dailyGoal > 0 && session.easyApplied === session.dailyGoal) {
    showNotification(
      "goal",
      "🎯 Daily Goal Reached!",
      `You hit your target of ${session.dailyGoal} applications. Great work!`
    );
  }
  broadcastUpdate();
}
async function handleJobFailed(payload) {
  broadcastUpdate();
}
async function handleJobSkipped(payload) {
  broadcastUpdate();
}
async function getStatus() {
  const status = await getStorage(STORAGE_KEYS.BOT_STATUS) || "idle";
  const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY) || DEFAULT_SESSION;
  return { status, session };
}
async function handleRetryJob(jobLink) {
  if (!jobLink) {
    log.warn("No job link provided for retry");
    return;
  }
  log.info(`Retrying job: ${jobLink}`);
  const tab = await chrome.tabs.create({ url: jobLink, active: true });
  const listener = (tabId, changeInfo) => {
    if (tabId === tab.id && changeInfo.status === "complete") {
      chrome.tabs.onUpdated.removeListener(listener);
      setTimeout(() => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            type: "RETRY_APPLY",
            timestamp: Date.now()
          }).catch((err) => {
            log.error("Failed to send RETRY_APPLY", err);
          });
        }
      }, 2e3);
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
  setTimeout(() => {
    chrome.tabs.onUpdated.removeListener(listener);
  }, 3e4);
}
function broadcastUpdate() {
  getStatus().then((data) => {
    chrome.runtime.sendMessage({
      type: "STATUS_UPDATE",
      payload: data,
      timestamp: Date.now()
    }).catch(() => {
    });
  });
}
function forwardToContentScript(message, excludeTabId) {
  chrome.tabs.query({ url: "https://www.linkedin.com/*" }, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id && tab.id !== excludeTabId) {
        chrome.tabs.sendMessage(tab.id, message).catch(() => {
        });
      }
    });
  });
}
async function openSidePanel(sender) {
  try {
    let windowId = sender.tab?.windowId;
    if (!windowId) {
      const currentWindow = await chrome.windows.getCurrent();
      windowId = currentWindow.id;
    }
    if (windowId) {
      await chrome.sidePanel.open({ windowId });
    }
  } catch (error) {
    log.error("Failed to open side panel", error);
  }
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  log.info(`Alarm fired: ${alarm.name}`);
  switch (alarm.name) {
    case "reminder_cleanup": {
      try {
        const { cleanupOldReminders } = await __vitePreload(async () => { const { cleanupOldReminders } = await import('../chunks/reminder-service-DLKb9z8W.js');return { cleanupOldReminders }},true?__vite__mapDeps([0,1]):void 0);
        await cleanupOldReminders();
      } catch (e) {
        log.error("Reminder cleanup failed", e);
      }
      break;
    }
    default: {
      if (alarm.name.startsWith("followup_")) {
        try {
          const { handleReminderAlarm } = await __vitePreload(async () => { const { handleReminderAlarm } = await import('../chunks/reminder-service-DLKb9z8W.js');return { handleReminderAlarm }},true?__vite__mapDeps([0,1]):void 0);
          await handleReminderAlarm(alarm.name);
        } catch (e) {
          log.error("Reminder alarm failed", e);
        }
      }
    }
  }
});
chrome.notifications.onButtonClicked.addListener(async (notificationId, buttonIndex) => {
  if (notificationId.startsWith("followup_")) {
    try {
      const { handleNotificationClick } = await __vitePreload(async () => { const { handleNotificationClick } = await import('../chunks/reminder-service-DLKb9z8W.js');return { handleNotificationClick }},true?__vite__mapDeps([0,1]):void 0);
      await handleNotificationClick(notificationId, buttonIndex);
    } catch (e) {
      log.error("Notification click handler failed", e);
    }
  }
});
chrome.alarms.create("reminder_cleanup", { periodInMinutes: 1440 });
log.info("Service worker initialized");
function showNotification(id, title, message) {
  try {
    chrome.notifications.create(`linkedapply_${id}_${Date.now()}`, {
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon-128.png"),
      title,
      message,
      priority: 1
    }, () => {
      if (chrome.runtime.lastError) {
      }
    });
  } catch {
  }
}
function updateBadge(count, state) {
  try {
    if (state === "stopped") {
      chrome.action.setBadgeText({ text: "" });
    } else {
      chrome.action.setBadgeText({ text: count > 0 ? String(count) : "" });
      chrome.action.setBadgeBackgroundColor({
        color: state === "error" ? "#ef4444" : "#22c55e"
      });
    }
  } catch {
  }
}
(async () => {
  const status = await getStorage(STORAGE_KEYS.BOT_STATUS);
  if (status === "searching" || status === "applying") {
    const session = await getStorage(STORAGE_KEYS.SESSION_SUMMARY);
    updateBadge(session?.easyApplied || 0, "running");
  }
})();
let _cachedAIClient = null;
let _aiClientCreatedAt = 0;
const AI_CLIENT_TTL = 5 * 60 * 1e3;
let _rateLimitUntil = 0;
let _rateLimitBackoff = 0;
const RATE_LIMIT_MAX_BACKOFF = 12e4;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[STORAGE_KEYS.AI_CONFIG]) {
    log.info("AI config changed — clearing rate limit and cached client");
    _rateLimitUntil = 0;
    _rateLimitBackoff = 0;
    _cachedAIClient = null;
    _aiClientCreatedAt = 0;
  }
});
async function getOrCreateAIClient() {
  const now = Date.now();
  if (_cachedAIClient && now - _aiClientCreatedAt < AI_CLIENT_TTL) {
    return _cachedAIClient;
  }
  _cachedAIClient = await createAIProviderFromStorage();
  _aiClientCreatedAt = now;
  return _cachedAIClient;
}
function checkRateLimit() {
  const now = Date.now();
  if (now < _rateLimitUntil) {
    const waitSec = Math.ceil((_rateLimitUntil - now) / 1e3);
    return `Rate limited — retry in ${waitSec}s`;
  }
  return null;
}
function handleRateLimitError(error) {
  const errorMsg = error.message || "";
  const isDailyQuota = errorMsg.includes("daily quota") || errorMsg.includes("PerDay") || errorMsg.includes("FreeTier");
  if (isDailyQuota) {
    _rateLimitUntil = Date.now() + 36e5;
    log.warn("🚫 Daily AI quota exhausted — skipping all AI calls for ~1 hour");
    return;
  }
  const retryMatch = errorMsg.match(/retry in ([\d.]+)s/i);
  let waitMs;
  if (retryMatch) {
    waitMs = Math.ceil(parseFloat(retryMatch[1]) * 1e3);
  } else {
    _rateLimitBackoff = _rateLimitBackoff ? Math.min(_rateLimitBackoff * 2, RATE_LIMIT_MAX_BACKOFF) : 15e3;
    waitMs = _rateLimitBackoff;
  }
  _rateLimitUntil = Date.now() + waitMs;
  log.warn(`⏳ AI rate limited — backing off for ${Math.ceil(waitMs / 1e3)}s`);
}
function clearRateLimit() {
  _rateLimitBackoff = 0;
}
async function handleAIMatchJob(payload) {
  const rateLimitMsg = checkRateLimit();
  if (rateLimitMsg) return { error: rateLimitMsg };
  try {
    const aiClient = await getOrCreateAIClient();
    if (!aiClient) return { error: "No AI provider configured" };
    const profile = await getStorage(STORAGE_KEYS.USER_PROFILE);
    if (!profile) return { error: "No user profile found" };
    const resumeText = await getStorage(STORAGE_KEYS.RESUME_TEXT);
    const skillsMap = await getStorage(STORAGE_KEYS.USER_SKILLS_MAP);
    const result = await aiMatchJob(
      aiClient,
      profile,
      payload.jobDescription,
      resumeText || void 0,
      skillsMap || void 0
    );
    if (!result) return { error: "AI returned no result (quota may be exhausted)" };
    clearRateLimit();
    await recordAICall();
    return { success: true, result };
  } catch (error) {
    if (error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED") || error.message?.includes("daily quota")) {
      handleRateLimitError(error);
      return { error: "AI quota exceeded — will retry after cooldown" };
    }
    if (error.message?.includes("503") || error.message?.includes("UNAVAILABLE")) {
      log.warn("⏳ Gemini server temporarily unavailable, will retry on next job");
      return { error: "AI server temporarily busy — will retry" };
    }
    log.error("AI match job failed in service worker", error);
    return { error: error.message || "AI match failed" };
  }
}
async function handleAITailorResume(payload) {
  const rateLimitMsg = checkRateLimit();
  if (rateLimitMsg) return { error: rateLimitMsg };
  try {
    const aiClient = await getOrCreateAIClient();
    if (!aiClient) return { error: "No AI provider configured" };
    const profile = await getStorage(STORAGE_KEYS.USER_PROFILE);
    if (!profile) return { error: "No user profile found" };
    const resumeText = payload.resumeOverride || await getStorage(STORAGE_KEYS.RESUME_TEXT);
    const skillsMap = await getStorage(STORAGE_KEYS.USER_SKILLS_MAP);
    if (payload.resumeOverride) {
      await chrome.storage.local.remove(STORAGE_KEYS.RESUME_STRUCTURED);
    }
    const result = await aiTailorResume(
      aiClient,
      profile,
      payload.jobDescription,
      null,
      resumeText || void 0,
      skillsMap || void 0
    );
    if (!result) return { error: "AI returned no result (quota may be exhausted)" };
    clearRateLimit();
    await recordAICall();
    return { success: true, result };
  } catch (error) {
    if (error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED") || error.message?.includes("daily quota")) {
      handleRateLimitError(error);
      return { error: "AI quota exceeded — will retry after cooldown" };
    }
    if (error.message?.includes("503") || error.message?.includes("UNAVAILABLE")) {
      log.warn("⏳ Gemini server temporarily unavailable, will retry on next job");
      return { error: "AI server temporarily busy — will retry" };
    }
    log.error("AI tailor resume failed in service worker", error);
    return { error: error.message || "AI tailor failed" };
  }
}
async function handleAICoverLetter(payload) {
  const rateLimitMsg = checkRateLimit();
  if (rateLimitMsg) return { error: rateLimitMsg };
  try {
    const aiClient = await getOrCreateAIClient();
    if (!aiClient) return { error: "No AI provider configured" };
    const profile = await getStorage(STORAGE_KEYS.USER_PROFILE);
    if (!profile) return { error: "No user profile found" };
    const result = await aiGenerateCoverLetter(
      aiClient,
      profile,
      payload.jobTitle || "Software Engineer",
      payload.company || "Unknown Company",
      payload.jobDescription || ""
    );
    if (!result) return { error: "AI returned no result (quota may be exhausted)" };
    clearRateLimit();
    await recordAICall();
    return { success: true, result };
  } catch (error) {
    if (error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED") || error.message?.includes("daily quota")) {
      handleRateLimitError(error);
      return { error: "AI quota exceeded — will retry after cooldown" };
    }
    if (error.message?.includes("503") || error.message?.includes("UNAVAILABLE")) {
      log.warn("⏳ Gemini server temporarily unavailable, will retry on next job");
      return { error: "AI server temporarily busy — will retry" };
    }
    log.error("AI cover letter failed in service worker", error);
    return { error: error.message || "AI cover letter failed" };
  }
}
async function handleAIStandOutTips(payload) {
  const rateLimitMsg = checkRateLimit();
  if (rateLimitMsg) return { error: rateLimitMsg };
  try {
    const aiClient = await getOrCreateAIClient();
    if (!aiClient) return { error: "No AI provider configured" };
    const profile = await getStorage(STORAGE_KEYS.USER_PROFILE);
    if (!profile) return { error: "No user profile found" };
    const result = await aiGenerateStandOutTips(
      aiClient,
      profile,
      payload.jobTitle || "Software Engineer",
      payload.company || "Unknown Company",
      payload.jobDescription || ""
    );
    if (!result) return { error: "AI returned no result (quota may be exhausted)" };
    clearRateLimit();
    await recordAICall();
    return { success: true, result };
  } catch (error) {
    if (error.message?.includes("429") || error.message?.includes("RESOURCE_EXHAUSTED") || error.message?.includes("daily quota")) {
      handleRateLimitError(error);
      return { error: "AI quota exceeded — will retry after cooldown" };
    }
    if (error.message?.includes("503") || error.message?.includes("UNAVAILABLE")) {
      log.warn("⏳ Gemini server temporarily unavailable, will retry on next job");
      return { error: "AI server temporarily busy — will retry" };
    }
    log.error("AI stand-out tips failed in service worker", error);
    return { error: error.message || "AI stand-out tips failed" };
  }
}
