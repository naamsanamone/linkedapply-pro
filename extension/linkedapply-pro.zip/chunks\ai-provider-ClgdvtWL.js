import { g as getStorage, S as STORAGE_KEYS, c as createLogger } from './constants-fenB-1Hb.js';

const log = createLogger("AIProvider");
class OpenAICompatibleProvider {
  provider;
  model;
  apiUrl;
  apiKey;
  constructor(config) {
    this.provider = config.provider;
    this.model = config.model;
    this.apiUrl = config.apiUrl.replace(/\/$/, "");
    this.apiKey = config.apiKey;
  }
  async testConnection() {
    try {
      const response = await fetch(`${this.apiUrl}/models`, {
        headers: { "Authorization": `Bearer ${this.apiKey}` }
      });
      if (!response.ok) {
        log.error(`Connection test failed: ${response.status} ${response.statusText}`);
        return false;
      }
      log.info(`${this.provider} connection successful`);
      return true;
    } catch (error) {
      log.error(`${this.provider} connection failed`, error);
      return false;
    }
  }
  async complete(prompt, options) {
    const messages = [];
    if (options?.systemMessage) {
      messages.push({ role: "system", content: options.systemMessage });
    }
    messages.push({ role: "user", content: prompt });
    const body = {
      model: this.model,
      messages,
      stream: false
    };
    if (options?.temperature !== void 0) {
      body.temperature = options.temperature;
    }
    if (options?.maxTokens) {
      body.max_tokens = options.maxTokens;
    }
    if (options?.responseFormat === "json") {
      body.response_format = { type: "json_object" };
    }
    const response = await fetch(`${this.apiUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${this.apiKey}`
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`${this.provider} API error ${response.status}: ${errorText}`);
    }
    const data = await response.json();
    if (data.error) {
      throw new Error(`${this.provider} API error: ${JSON.stringify(data.error)}`);
    }
    const content = data.choices?.[0]?.message?.content;
    if (!content) {
      throw new Error(`${this.provider} returned empty response`);
    }
    log.debug(`${this.provider} completion received (${content.length} chars)`);
    return content;
  }
  async completeJSON(prompt, options) {
    const raw = await this.complete(prompt, {
      ...options,
      responseFormat: "json"
    });
    try {
      return JSON.parse(raw);
    } catch {
      const jsonMatch = raw.match(/```(?:json)?\s*([\s\S]*?)```/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[1].trim());
      }
      throw new Error(`Failed to parse JSON from ${this.provider} response: ${raw.substring(0, 200)}`);
    }
  }
}
class GeminiProvider {
  provider = "gemini";
  model;
  apiKey;
  baseUrl;
  constructor(config) {
    const deprecatedModels = {
      "gemini-1.5-flash": "gemini-2.5-flash",
      "gemini-1.5-pro": "gemini-2.5-flash",
      "gemini-pro": "gemini-2.5-flash",
      "gemini-2.0-flash": "gemini-2.5-flash"
    };
    this.model = deprecatedModels[config.model] || config.model;
    this.apiKey = config.apiKey;
    this.baseUrl = `https://generativelanguage.googleapis.com/v1beta/models/${this.model}`;
    if (deprecatedModels[config.model]) {
      log.info(`Auto-corrected deprecated model "${config.model}" → "${this.model}"`);
    }
  }
  async testConnection() {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models?key=${this.apiKey}`
      );
      if (!response.ok) {
        log.error(`Gemini connection test failed: ${response.status}`);
        return false;
      }
      log.info("Gemini connection successful");
      return true;
    } catch (error) {
      log.error("Gemini connection failed", error);
      return false;
    }
  }
  async complete(prompt, options) {
    const maxRetries = 3;
    let lastError = null;
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const body = {
          contents: [{ parts: [{ text: prompt }] }],
          safetySettings: [
            { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_NONE" },
            { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_NONE" }
          ]
        };
        if (options?.temperature !== void 0) {
          body.generationConfig = { temperature: options.temperature };
        }
        if (options?.maxTokens) {
          body.generationConfig = { ...body.generationConfig, maxOutputTokens: options.maxTokens };
        }
        if (options?.responseFormat === "json") {
          body.generationConfig = { ...body.generationConfig, responseMimeType: "application/json" };
        }
        const url = `${this.baseUrl}:generateContent?key=${this.apiKey}`;
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body)
        });
        if (!response.ok) {
          const errorText = await response.text();
          if ((response.status === 429 || response.status === 503) && attempt < maxRetries - 1) {
            if (response.status === 429) {
              const isDailyQuota = errorText.includes("PerDay") || errorText.includes("FreeTier") || errorText.includes("RESOURCE_EXHAUSTED");
              if (isDailyQuota) {
                log.warn("🚫 Daily AI quota exhausted — skipping retry (resets in ~1 hour)");
                throw new Error(`Gemini daily quota exhausted (1,500 req/day free tier). Bot will continue without AI scoring.`);
              }
            }
            const retryMatch = errorText.match(/retry in ([\d.]+)s/i) || errorText.match(/"retryDelay":\s*"(\d+)s"/);
            const waitSec = retryMatch ? Math.min(parseFloat(retryMatch[1]), 60) : 15 * (attempt + 1);
            log.warn(`⏳ Gemini ${response.status} (${response.status === 503 ? "server busy" : "rate limit"}) — auto-retrying in ${Math.ceil(waitSec)}s (attempt ${attempt + 1}/${maxRetries})`);
            await new Promise((r) => setTimeout(r, waitSec * 1e3));
            continue;
          }
          throw new Error(`Gemini API error ${response.status}: ${errorText}`);
        }
        const data = await response.json();
        if (data.error) {
          throw new Error(`Gemini API error: ${JSON.stringify(data.error)}`);
        }
        const content = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!content) {
          throw new Error("Gemini returned empty response — possibly blocked by safety filters");
        }
        log.debug(`Gemini completion received (${content.length} chars)`);
        return content;
      } catch (error) {
        lastError = error;
        if (attempt < maxRetries - 1 && (error.message?.includes("429") || error.message?.includes("503"))) {
          continue;
        }
        throw error;
      }
    }
    throw lastError || new Error("Max retries exceeded");
  }
  async completeJSON(prompt, options) {
    const enrichedPrompt = prompt + "\n\nIMPORTANT: Return ONLY valid JSON. No markdown, no code blocks, no explanations. Ensure JSON is complete and properly closed.";
    const raw = await this.complete(enrichedPrompt, { ...options, responseFormat: "json" });
    let cleaned = raw.trim();
    cleaned = cleaned.replace(/^```(?:json|JSON)?\s*\n?/m, "");
    cleaned = cleaned.replace(/\n?\s*```\s*$/m, "");
    if (cleaned.startsWith("`") && cleaned.endsWith("`")) {
      cleaned = cleaned.slice(1, -1);
    }
    cleaned = cleaned.trim();
    try {
      return JSON.parse(cleaned);
    } catch {
      const repaired = this.repairJSON(cleaned);
      if (repaired) {
        try {
          return JSON.parse(repaired);
        } catch {
        }
      }
      throw new Error(`Failed to parse JSON from Gemini response: ${cleaned.substring(0, 200)}`);
    }
  }
  /** Try to repair truncated JSON by closing open brackets/braces */
  repairJSON(json) {
    try {
      const attempt1 = this.tryCloseJSON(json);
      if (attempt1) {
        try {
          JSON.parse(attempt1);
          return attempt1;
        } catch {
        }
      }
      let stripped = json;
      if (this.isInString(stripped)) stripped += '"';
      stripped = stripped.replace(/,\s*\{[^}]*$/s, "");
      stripped = stripped.replace(/,\s*"[^"]*"\s*:\s*(?:"[^"]*"?|[^,}\]]*)?$/s, "");
      stripped = stripped.replace(/[,:\s]+$/, "");
      const attempt2 = this.tryCloseJSON(stripped);
      if (attempt2) {
        try {
          JSON.parse(attempt2);
          log.warn("Repaired truncated JSON (stripped incomplete items)");
          return attempt2;
        } catch {
        }
      }
      let progressive = stripped;
      for (let i = 0; i < 10; i++) {
        const prevLen = progressive.length;
        progressive = progressive.replace(/,\s*\{[^{}]*\}?\s*$/s, "");
        progressive = progressive.replace(/,\s*"[^"]*"\s*:\s*(?:"[^"]*"|[\d.]+|true|false|null|\[[^\]]*\])\s*$/s, "");
        progressive = progressive.replace(/[,:\s]+$/, "");
        if (progressive.length === prevLen) break;
        const attempt3 = this.tryCloseJSON(progressive);
        if (attempt3) {
          try {
            JSON.parse(attempt3);
            log.warn(`Repaired truncated JSON (progressive strip, pass ${i + 1})`);
            return attempt3;
          } catch {
          }
        }
      }
      return attempt1;
    } catch {
      return null;
    }
  }
  /** Check if the string ends inside an open JSON string */
  isInString(json) {
    let inString = false, escape = false;
    for (const ch of json) {
      if (escape) {
        escape = false;
        continue;
      }
      if (ch === "\\") {
        escape = true;
        continue;
      }
      if (ch === '"') {
        inString = !inString;
      }
    }
    return inString;
  }
  /** Close open strings, brackets, braces */
  tryCloseJSON(json) {
    let repaired = json;
    if (this.isInString(repaired)) repaired += '"';
    repaired = repaired.replace(/[,:\s]+$/, "");
    let braces = 0, brackets = 0, inString = false, escape = false;
    for (const ch of repaired) {
      if (escape) {
        escape = false;
        continue;
      }
      if (ch === "\\") {
        escape = true;
        continue;
      }
      if (ch === '"') {
        inString = !inString;
        continue;
      }
      if (inString) continue;
      if (ch === "{") braces++;
      else if (ch === "}") braces--;
      else if (ch === "[") brackets++;
      else if (ch === "]") brackets--;
    }
    for (let i = 0; i < brackets; i++) repaired += "]";
    for (let i = 0; i < braces; i++) repaired += "}";
    return repaired;
  }
}
function createAIProvider(config) {
  switch (config.provider) {
    case "openai":
      return new OpenAICompatibleProvider(config);
    case "deepseek":
      return new OpenAICompatibleProvider(config);
    case "gemini":
      return new GeminiProvider(config);
    default:
      throw new Error(`Unknown AI provider: ${config.provider}`);
  }
}
async function createAIProviderFromStorage() {
  const config = await getStorage(STORAGE_KEYS.AI_CONFIG);
  if (!config || !config.apiKey) {
    log.debug("No AI config found in storage");
    return null;
  }
  try {
    const provider = createAIProvider(config);
    log.info(`AI provider created: ${config.provider} (${config.model})`);
    return provider;
  } catch (error) {
    log.error("Failed to create AI provider from storage", error);
    return null;
  }
}

export { createAIProvider, createAIProviderFromStorage };
