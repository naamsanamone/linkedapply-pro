const LOG_COLORS = {
  debug: "#94a3b8",
  info: "#6366f1",
  warn: "#f59e0b",
  error: "#ef4444"
};
const LOG_PREFIX = "🚀 LinkedApply";
function formatTimestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour12: false,
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
}
function log(level, context, message, data) {
  const timestamp = formatTimestamp();
  const color = LOG_COLORS[level];
  const prefix = `%c${LOG_PREFIX}%c [${timestamp}] [${context}]`;
  const args = [
    prefix,
    `color: ${color}; font-weight: bold;`,
    `color: ${color};`,
    message
  ];
  if (data !== void 0) {
    args.push(data);
  }
  switch (level) {
    case "debug":
      console.debug(...args);
      break;
    case "info":
      console.info(...args);
      break;
    case "warn":
      console.warn(...args);
      break;
    case "error":
      console.error(...args);
      break;
  }
}
function createLogger(context) {
  return {
    debug: (message, data) => log("debug", context, message, data),
    info: (message, data) => log("info", context, message, data),
    warn: (message, data) => log("warn", context, message, data),
    error: (message, data) => log("error", context, message, data)
  };
}

async function getStorage(key) {
  return new Promise((resolve) => {
    chrome.storage.local.get(key, (result) => {
      resolve(result[key] ?? null);
    });
  });
}
async function setStorage(key, value) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ [key]: value }, resolve);
  });
}

const DEFAULT_CLICK_GAP = 2e3;
const STORAGE_KEYS = {
  USER_PROFILE: "user_profile",
  SEARCH_PREFS: "search_preferences",
  QUESTION_DEFAULTS: "question_defaults",
  BOT_SETTINGS: "bot_settings",
  AI_CONFIG: "ai_config",
  SESSION_SUMMARY: "session_summary",
  APPLIED_JOBS: "applied_jobs",
  FAILED_JOBS: "failed_jobs",
  BOT_STATUS: "bot_status",
  SUBSCRIPTION: "subscription",
  AUTH_TOKEN: "auth_token",
  THEME: "theme",
  ONBOARDING_COMPLETE: "onboarding_complete",
  FOLLOW_UP_REMINDERS: "follow_up_reminders",
  REMINDER_SETTINGS: "reminder_settings",
  LAST_SYNC_TIMESTAMP: "last_sync_timestamp",
  USER_SKILLS_MAP: "user_skills_map",
  ANSWER_MEMORY: "answer_memory",
  RESUME_TEXT: "resume_text",
  RESUME_STRUCTURED: "resume_structured",
  MATCH_FILTER: "match_filter",
  USAGE_STATE: "linkedapply_usage_state",
  PRE_APPLY_REVIEW: "pre_apply_review",
  PRE_APPLY_DECISION: "pre_apply_decision",
  PRE_APPLY_SETTINGS: "pre_apply_settings",
  RESUME_TEMPLATES: "resume_templates",
  DEFAULT_TEMPLATE_ID: "default_template_id",
  CUSTOM_QA: "custom_qa"
};
const DEFAULT_PROFILE = {
  firstName: "",
  middleName: "",
  lastName: "",
  email: "",
  phoneNumber: "",
  phoneCountryCode: "US (+1)",
  currentCity: "",
  street: "",
  state: "",
  zipcode: "",
  country: "",
  ethnicity: "Decline",
  gender: "",
  disabilityStatus: "Decline",
  veteranStatus: "Decline",
  highestEducation: ""
};
const DEFAULT_SEARCH_PREFS = {
  searchTerms: [],
  searchLocation: "",
  sortBy: "",
  datePosted: "",
  easyApplyOnly: true,
  companies: [],
  badWords: [],
  goodWords: [],
  aboutCompanyBadWords: [],
  aboutCompanyGoodWords: [],
  securityClearance: false,
  didMasters: false,
  currentExperience: 0
};
const DEFAULT_BOT_SETTINGS = {
  closeTabs: true,
  followCompanies: false,
  runNonStop: false,
  clickGap: DEFAULT_CLICK_GAP,
  speedMode: "normal",
  customMinDelay: 1e3,
  customMaxDelay: 3e3,
  smoothScroll: true,
  useTailoredResume: false
};
const DEFAULT_SESSION = {
  totalRuns: 0,
  easyApplied: 0,
  externalCollected: 0,
  failed: 0,
  skipped: 0,
  randomAnswers: 0,
  tailoredCount: 0,
  startTime: "",
  endTime: "",
  estimatedTimeSaved: 0,
  dailyGoal: 25
};

export { DEFAULT_PROFILE as D, STORAGE_KEYS as S, DEFAULT_SEARCH_PREFS as a, DEFAULT_BOT_SETTINGS as b, createLogger as c, DEFAULT_SESSION as d, getStorage as g, setStorage as s };
