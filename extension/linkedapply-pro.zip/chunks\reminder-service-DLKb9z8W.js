import { g as getStorage, S as STORAGE_KEYS, s as setStorage, c as createLogger } from './constants-fenB-1Hb.js';

const log = createLogger("Reminders");
const REMINDERS_KEY = STORAGE_KEYS.FOLLOW_UP_REMINDERS;
const ALARM_PREFIX = "followup_";
const DEFAULT_FOLLOW_UP_DAYS = 7;
async function scheduleReminder(job, daysFromNow = DEFAULT_FOLLOW_UP_DAYS, notes = "") {
  const reminderDate = /* @__PURE__ */ new Date();
  reminderDate.setDate(reminderDate.getDate() + daysFromNow);
  const reminder = {
    id: `${ALARM_PREFIX}${job.id}_${Date.now()}`,
    jobId: job.id,
    jobTitle: job.title,
    company: job.company,
    reminderDate: reminderDate.toISOString(),
    status: "pending",
    createdAt: (/* @__PURE__ */ new Date()).toISOString(),
    notes
  };
  const reminders = await getReminders();
  reminders.push(reminder);
  await setStorage(REMINDERS_KEY, reminders);
  const delayMs = reminderDate.getTime() - Date.now();
  await chrome.alarms.create(reminder.id, {
    when: Date.now() + delayMs
  });
  log.info(`Reminder scheduled: ${job.company} — ${job.title} in ${daysFromNow} days`);
  return reminder;
}
async function autoScheduleReminder(job) {
  const settings = await getStorage(STORAGE_KEYS.REMINDER_SETTINGS);
  if (!settings?.autoRemind) return;
  const days = settings.followUpDays || DEFAULT_FOLLOW_UP_DAYS;
  await scheduleReminder(job, days, "Auto-scheduled follow-up");
}
async function getReminders() {
  return await getStorage(REMINDERS_KEY) || [];
}
async function getPendingReminders() {
  const reminders = await getReminders();
  return reminders.filter((r) => r.status === "pending");
}
async function getOverdueReminders() {
  const reminders = await getReminders();
  const now = /* @__PURE__ */ new Date();
  return reminders.filter(
    (r) => r.status === "pending" && new Date(r.reminderDate) <= now
  );
}
async function dismissReminder(reminderId) {
  await updateReminderStatus(reminderId, "dismissed");
  await chrome.alarms.clear(reminderId);
}
async function completeReminder(reminderId) {
  await updateReminderStatus(reminderId, "completed");
  await chrome.alarms.clear(reminderId);
}
async function snoozeReminder(reminderId, days) {
  const reminders = await getReminders();
  const idx = reminders.findIndex((r) => r.id === reminderId);
  if (idx < 0) return;
  const newDate = /* @__PURE__ */ new Date();
  newDate.setDate(newDate.getDate() + days);
  reminders[idx].reminderDate = newDate.toISOString();
  reminders[idx].status = "pending";
  await setStorage(REMINDERS_KEY, reminders);
  await chrome.alarms.clear(reminderId);
  await chrome.alarms.create(reminderId, {
    when: newDate.getTime()
  });
  log.info(`Reminder snoozed ${days} days: ${reminderId}`);
}
async function deleteReminder(reminderId) {
  const reminders = await getReminders();
  const filtered = reminders.filter((r) => r.id !== reminderId);
  await setStorage(REMINDERS_KEY, filtered);
  await chrome.alarms.clear(reminderId);
}
async function cleanupOldReminders() {
  const reminders = await getReminders();
  const cutoff = /* @__PURE__ */ new Date();
  cutoff.setDate(cutoff.getDate() - 30);
  const filtered = reminders.filter((r) => {
    if (r.status === "pending") return true;
    return new Date(r.createdAt) > cutoff;
  });
  const removed = reminders.length - filtered.length;
  if (removed > 0) {
    await setStorage(REMINDERS_KEY, filtered);
    log.info(`Cleaned up ${removed} old reminders`);
  }
  return removed;
}
async function handleReminderAlarm(alarmName) {
  if (!alarmName.startsWith(ALARM_PREFIX)) return;
  const reminders = await getReminders();
  const reminder = reminders.find((r) => r.id === alarmName);
  if (!reminder || reminder.status !== "pending") return;
  await chrome.notifications.create(alarmName, {
    type: "basic",
    iconUrl: chrome.runtime.getURL("icons/icon128.png"),
    title: "🔔 Follow-Up Reminder",
    message: `Time to follow up with ${reminder.company} about "${reminder.jobTitle}"`,
    priority: 2,
    buttons: [
      { title: "✅ Done" },
      { title: "⏰ Snooze 2 days" }
    ],
    requireInteraction: true
  });
  await updateReminderStatus(alarmName, "fired");
  log.info(`Reminder fired: ${reminder.company} — ${reminder.jobTitle}`);
}
async function handleNotificationClick(notificationId, buttonIndex) {
  if (!notificationId.startsWith(ALARM_PREFIX)) return;
  if (buttonIndex === 0) {
    await completeReminder(notificationId);
  } else if (buttonIndex === 1) {
    await snoozeReminder(notificationId, 2);
  }
  chrome.notifications.clear(notificationId);
}
async function updateReminderStatus(reminderId, status) {
  const reminders = await getReminders();
  const idx = reminders.findIndex((r) => r.id === reminderId);
  if (idx >= 0) {
    reminders[idx].status = status;
    await setStorage(REMINDERS_KEY, reminders);
  }
}

export { autoScheduleReminder, cleanupOldReminders, completeReminder, deleteReminder, dismissReminder, getOverdueReminders, getPendingReminders, getReminders, handleNotificationClick, handleReminderAlarm, scheduleReminder, snoozeReminder };
