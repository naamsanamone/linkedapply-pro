import { _ as __vitePreload } from './preload-helper-BelkbqnE.js';
import { c as createLogger } from './constants-fenB-1Hb.js';

const log = createLogger("ResumeParser");
async function extractTextFromPDF(file) {
  try {
    log.info(`Parsing PDF: ${file.name} (${Math.round(file.size / 1024)}KB)`);
    const pdfjsLib = await __vitePreload(() => import('./pdf-DB2xNj8o.js'),true?[]:void 0);
    pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("/assets/pdf.worker-iVMkNdeB.mjs", import.meta.url).toString();
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = "";
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const content = await page.getTextContent();
      const pageText = content.items.map((item) => item.str).join(" ");
      fullText += pageText + "\n";
    }
    const wordCount = fullText.split(/\s+/).filter(Boolean).length;
    log.info(`Resume parsed: ${pdf.numPages} pages, ${wordCount} words`);
    return fullText.trim();
  } catch (error) {
    log.error("Failed to parse PDF", error);
    throw new Error("Failed to parse PDF. Please ensure it is a valid PDF with selectable text.");
  }
}

export { extractTextFromPDF };
