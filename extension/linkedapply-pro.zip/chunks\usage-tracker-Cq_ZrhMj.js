import { g as getStorage, S as STORAGE_KEYS, s as setStorage, c as createLogger } from './constants-fenB-1Hb.js';

const log = createLogger("UsageTracker");
const USAGE_KEY = STORAGE_KEYS.USAGE_STATE;
const DEFAULT_USAGE = {
  tier: "byok",
  dailyCalls: { date: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10), count: 0 },
  totalCalls: 0
};
async function getUsageState() {
  const state = await getStorage(USAGE_KEY);
  if (!state) return { ...DEFAULT_USAGE };
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (state.dailyCalls.date !== today) {
    state.dailyCalls = { date: today, count: 0 };
    await setStorage(USAGE_KEY, state);
  }
  return state;
}
async function recordAICall() {
  const state = await getUsageState();
  const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  if (state.dailyCalls.date !== today) {
    state.dailyCalls = { date: today, count: 1 };
  } else {
    state.dailyCalls.count++;
  }
  state.totalCalls++;
  state.lastCallAt = (/* @__PURE__ */ new Date()).toISOString();
  await setStorage(USAGE_KEY, state);
  log.info(`AI call #${state.dailyCalls.count} today (${state.totalCalls} total)`);
  return state;
}
function estimateCost(calls) {
  const est = calls * 1500 * 15e-8;
  return est < 0.01 ? "<$0.01" : `~$${est.toFixed(3)}`;
}

export { estimateCost as e, getUsageState as g, recordAICall as r };
