import './chunks/inter-CIshzJL1.js';
import { g as getStorage, c as createLogger, S as STORAGE_KEYS } from './chunks/constants-fenB-1Hb.js';

const log = createLogger("Popup");
const statusDot = document.getElementById("status-dot");
const statusText = document.getElementById("status-text");
const startBtn = document.getElementById("start-btn");
const progressBar = document.getElementById("progress-bar");
const dashboardBtn = document.getElementById("dashboard-btn");
const settingsBtn = document.getElementById("settings-btn");
const statApplied = document.getElementById("stat-applied");
const statTailored = document.getElementById("stat-tailored");
const statSkipped = document.getElementById("stat-skipped");
const statTime = document.getElementById("stat-time");
let currentStatus = "idle";
async function init() {
  log.info("Popup opened");
  const [status, session] = await Promise.all([
    getStorage(STORAGE_KEYS.BOT_STATUS),
    getStorage(STORAGE_KEYS.SESSION_SUMMARY)
  ]);
  if (status) updateStatusUI(status);
  if (session) updateStatsUI(session);
  startBtn.addEventListener("click", handleStartStop);
  dashboardBtn.addEventListener("click", openDashboard);
  settingsBtn.addEventListener("click", openSettings);
  const reviewBtn = document.getElementById("review-btn");
  reviewBtn?.addEventListener("click", openDashboard);
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === "STATUS_UPDATE") {
      updateStatusUI(message.payload.status);
      if (message.payload.session) {
        updateStatsUI(message.payload.session);
      }
    }
  });
}
let isHandlingStartStop = false;
async function handleStartStop() {
  if (isHandlingStartStop) return;
  isHandlingStartStop = true;
  startBtn.setAttribute("disabled", "true");
  try {
    if (currentStatus === "idle" || currentStatus === "stopped" || currentStatus === "paused") {
      await chrome.runtime.sendMessage({ type: "START_BOT", timestamp: Date.now() });
      updateStatusUI("searching");
    } else {
      await chrome.runtime.sendMessage({ type: "STOP_BOT", timestamp: Date.now() });
      updateStatusUI("stopped");
    }
  } catch (err) {
    log.error("Failed to toggle bot", err);
  } finally {
    setTimeout(() => {
      startBtn.removeAttribute("disabled");
      isHandlingStartStop = false;
    }, 600);
  }
}
async function openDashboard() {
  try {
    const currentWindow = await chrome.windows.getCurrent();
    if (currentWindow.id) {
      await chrome.sidePanel.open({ windowId: currentWindow.id });
    }
  } catch (error) {
    log.error("Failed to open sidePanel directly from popup", error);
    chrome.runtime.sendMessage({ type: "OPEN_SIDEPANEL", timestamp: Date.now() });
  }
  window.close();
}
function openSettings() {
  chrome.runtime.openOptionsPage();
  window.close();
}
function updateStatusUI(status) {
  currentStatus = status;
  statusDot.className = "status-dot";
  switch (status) {
    case "searching":
    case "filtering":
    case "applying":
    case "reviewing":
      statusDot.classList.add("status-dot--active");
      startBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg> Stop`;
      progressBar.style.display = "block";
      document.getElementById("popup-root")?.classList.add("popup--running");
      break;
    case "paused":
      statusDot.classList.add("status-dot--idle");
      startBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Resume`;
      break;
    case "error":
      statusDot.classList.add("status-dot--error");
      startBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Retry`;
      break;
    default:
      statusDot.classList.add("status-dot--idle");
      startBtn.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z"/></svg> Start`;
      progressBar.style.display = "none";
      document.getElementById("popup-root")?.classList.remove("popup--running");
  }
  const statusLabels = {
    idle: "Ready to start",
    searching: "Searching jobs...",
    filtering: "Applying filters...",
    applying: "Applying to job...",
    reviewing: "Reviewing job...",
    paused: "Paused",
    error: "Error occurred",
    stopped: "Stopped"
  };
  statusText.textContent = statusLabels[status] || "Unknown";
  const reviewBtn = document.getElementById("review-btn");
  if (reviewBtn) reviewBtn.style.display = status === "reviewing" ? "block" : "none";
}
function updateStatsUI(session) {
  statApplied.textContent = String(session.easyApplied);
  statTailored.textContent = String(session.tailoredCount || 0);
  statSkipped.textContent = String(session.skipped);
  const minutes = Math.round(session.estimatedTimeSaved / 60);
  statTime.textContent = minutes >= 60 ? `${Math.round(minutes / 60)}h` : `${minutes}m`;
}
document.addEventListener("DOMContentLoaded", init);
